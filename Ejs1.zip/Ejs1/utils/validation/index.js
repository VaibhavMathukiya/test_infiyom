const Register = require("../validation/registeruserValidation")
const loginUser = require("../validation/loginuserValidation")


module.exports ={
    Register,
    loginUser
}